
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectItem } from "@/components/ui/select";

export default function FeeSheetCalculator() {
  const [purchasePrice, setPurchasePrice] = useState(0);
  const [downPayment, setDownPayment] = useState(0.3);
  const [loanProgram, setLoanProgram] = useState("Foreign National");
  const [interestRate, setInterestRate] = useState(6.5);
  const [term, setTerm] = useState(30);

  const loanAmount = purchasePrice * (1 - downPayment);
  const monthlyRate = interestRate / 100 / 12;
  const totalPayments = term * 12;
  const monthlyPayment = loanAmount
    ? (loanAmount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -totalPayments))
    : 0;

  const closingCosts = loanAmount * 0.03;
  const cashToClose = purchasePrice * downPayment + closingCosts;

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-6">
      <h1 className="text-2xl font-bold">Calculadora de Préstamos</h1>
      <Card>
        <CardContent className="grid gap-4 p-4">
          <Input
            type="number"
            placeholder="Precio de compra"
            onChange={(e) => setPurchasePrice(Number(e.target.value))}
          />
          <Input
            type="number"
            step="0.01"
            placeholder="% Down Payment (ej. 0.3 para 30%)"
            onChange={(e) => setDownPayment(Number(e.target.value))}
          />
          <Select onValueChange={setLoanProgram} defaultValue={loanProgram}>
            <SelectItem value="Foreign National">Foreign National</SelectItem>
            <SelectItem value="DSCR">DSCR</SelectItem>
            <SelectItem value="Bank Statement">Bank Statement</SelectItem>
            <SelectItem value="Profit and Loss">Profit and Loss</SelectItem>
            <SelectItem value="W2 / Full Doc">W2 / Full Doc</SelectItem>
            <SelectItem value="FHA">FHA</SelectItem>
            <SelectItem value="Conventional">Conventional</SelectItem>
            <SelectItem value="Construction">Construction</SelectItem>
          </Select>
          <Input
            type="number"
            step="0.01"
            placeholder="Tasa de interés (%)"
            value={interestRate}
            onChange={(e) => setInterestRate(Number(e.target.value))}
          />
          <Input
            type="number"
            placeholder="Término (años)"
            value={term}
            onChange={(e) => setTerm(Number(e.target.value))}
          />
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 space-y-2">
          <p><strong>Loan Amount:</strong> ${loanAmount.toLocaleString()}</p>
          <p><strong>Pago mensual estimado (P&I):</strong> ${monthlyPayment.toFixed(2)}</p>
          <p><strong>Costos de cierre (estimado 3%):</strong> ${closingCosts.toLocaleString()}</p>
          <p><strong>Total a llevar al cierre:</strong> ${cashToClose.toLocaleString()}</p>
        </CardContent>
      </Card>

      <Button onClick={() => alert("PDF/Export pronto disponible")}>Exportar / Compartir</Button>
    </div>
  );
}
